const AWS = require('aws-sdk');
const iotData = new AWS.IotData({endpoint: 'a3c4bo3z0e3m5n-ats.iot.us-east-1.amazonaws.com'});

exports.handler = (event, context, callback) => {
  console.log(event.message)
  
  var response = {};
  response.message = event.message == undefined ? null : event.message ;
  response.url = event.url == undefined ? null : event.url;
  
  const iotParams = {
    payload: JSON.stringify(response),
    topic: 'myTopic'
  }

  iotData.publish(iotParams, (err, data) => {
    if (err) {
    }
    callback(null, { success: true })
  })
}