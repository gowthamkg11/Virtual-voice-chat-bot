import json
import boto3

def lambda_handler(event, context):
    
    intent = event["request"]["intent"]
    intent_name = intent["name"]
    time = 8000 if(intent_name == "shopping") else 5000
    
    invokeLam = boto3.client("lambda", region_name="us-east-1")
    payload = {"message": time}
    resp = invokeLam.invoke(FunctionName="web_socket", InvocationType="Event", Payload=json.dumps(payload))
    
    output = ""
    if(intent_name == "breakfast"):
        output = "Ooh, Thats great granny, did you take your medicine?"
    elif(intent_name == "shopping"):
        output = "Oops, I'm sorry granny. We should go to doctor for an appointment. \
        Shall we plan for shopping on some other day?"
    
    response = {
        "version": "1.0",
        "response": {
            "outputSpeech": {
                "type": "PlainText",
                "text": output,
                "playBehavior": "REPLACE_ENQUEUED"
            }
        }
    }
    
    return response
