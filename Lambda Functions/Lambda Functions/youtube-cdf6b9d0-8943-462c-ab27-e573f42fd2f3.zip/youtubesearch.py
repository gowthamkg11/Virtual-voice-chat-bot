import json
import requests
import boto3

def lambda_handler(event, context):
    
    query = event["request"]["intent"]["slots"]["voiceInput"]["value"]
    youtube_api = "https://www.googleapis.com/youtube/v3/search?part=snippet&" + "q=" + query + "&key=AIzaSyAqBFUnaRpykaHlOk8HFQEBm7gLV0sS-Zg"

    response = requests.get(youtube_api)
    response_dict = json.loads(response.content)
    
    url = "https://www.youtube.com/watch?v=" + str(response_dict["items"][0]["id"]["videoId"])
    output = "Playing your video on " + query
    
    invokeLam = boto3.client("lambda", region_name="us-east-1")
    payload = {"url": url}
    resp = invokeLam.invoke(FunctionName="web_socket", InvocationType="Event", Payload=json.dumps(payload))
    
    print(output)
    
    response = {
        "version": "1.0",
        "response": {
            "outputSpeech": {
                "type": "PlainText",
                "text": output,
                "playBehavior": "REPLACE_ENQUEUED"
            }
        }
    }

    return response
