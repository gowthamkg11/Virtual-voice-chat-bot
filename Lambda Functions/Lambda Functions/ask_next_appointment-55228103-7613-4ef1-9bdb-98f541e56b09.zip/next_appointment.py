import boto3
import pymysql
import json


def lambda_handler(event, context):

    try:
        host = "medication.c0297vvico7h.us-east-2.rds.amazonaws.com"
        port = 3306
        dbname = "medicalDetails"
        user = "keerthiT02"
        password = "Pari2811"

        conn = pymysql.connect(host, user=user, port=port, passwd=password, db=dbname)
        cursor = conn.cursor()

        invokeLam = boto3.client("lambda", region_name="us-east-1")
        payload = {"message": "4000"}

        print(payload)
        # For InvocationType = "Event"
        resp = invokeLam.invoke(FunctionName="web_socket", InvocationType="Event", Payload=json.dumps(payload))
        print(resp)


        query = """
            select next_appointment_date from appointments where counter = (select max(counter) from appointments);
        """

        print(query)

        cursor.execute(query)
        conn.commit()

        next_appointment_date = cursor.fetchall()[0][0]

        print(next_appointment_date)

        response = {
            "version": "1.0",
            "response": {
                "outputSpeech": {
                    "type": "PlainText",
                    "text": "Your next appointment is on " + str(next_appointment_date),
                    "playBehavior": "REPLACE_ENQUEUED"
                }
            }
        }

        print(response)

        return response

    except Exception as e:
        print(e.message)
