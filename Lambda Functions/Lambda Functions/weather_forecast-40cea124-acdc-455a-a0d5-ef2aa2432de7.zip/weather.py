import requests
import simplejson
import boto3, json

def request_handler(event, context):
    input = event["request"]
    voice_input_str = input["intent"]["name"]
    url = "http://api.apixu.com/v1/forecast.json?key=b0729f49fc254ec081185146180610&q=singapore"
    response = requests.get(url)
    content_dict = simplejson.loads(response.content)
    
    invokeLam = boto3.client("lambda", region_name="us-east-1")
    payload = {"message": "6500"}
    resp = invokeLam.invoke(FunctionName = "web_socket", InvocationType = "Event", Payload = json.dumps(payload))

    current_weather = content_dict["current"]
    forecast_weather = content_dict["forecast"]["forecastday"][0]["day"]

    current_temp = current_weather["temp_c"]
    current_condition = current_weather["condition"]["text"]

    # forecast_temp = forecast_weather["avgtemp_c"]
    forecast_condition = forecast_weather["condition"]["text"]

    output_str = ""

    if "out" in voice_input_str or "outside" in voice_input_str:
        if current_temp >= 32:
            output_str = "The weather is " + str(current_temp) + ". Its sunny, let's take an umbrella."
        elif current_temp < 31:
            if "rainy" in forecast_condition:
                output_str = "The weather is " + str(current_temp) + ". There is a possibility of a rain, let's take an umbrella with us"
            else:
                output_str = "The weather is " + str(current_temp) + ". Climate is good to go out, let's go to meet doctor!"
    else:
        output_str = "Current weather is " + str(current_temp) + " Weather condition is " + str(current_condition)

    output_json = {
        "version": "1.0",
        "response": {
            "outputSpeech": {
              "type": "PlainText",
              "text": output_str,
              "playBehavior": "REPLACE_ENQUEUED"  
              }
        }
    }
    return output_json




